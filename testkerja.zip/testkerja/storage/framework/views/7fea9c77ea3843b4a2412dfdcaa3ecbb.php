<div class="container">
    <h1>Daftar Produk</h1>
    <button><a href="<?php echo e(route('produk.create')); ?>">Tambah data</a></button>
    <button><a href="<?php echo e(route('produk.show')); ?>">Barang bisa dijual</a></button>

    <!-- Tampilkan data produk di sini sesuai dengan respons API -->
    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Kategori ID</th>
                <th>Status ID</th>
                <th>Action</th>
                <!-- Tambahkan kolom lainnya sesuai kebutuhan -->
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->nama_produk); ?></td>
                    <td><?php echo e($product->harga); ?></td>
                    <td><?php echo e($product->kategori->kategori); ?></td>
                    <td><?php echo e($product->status->status); ?></td>
                    <td>
                       
                        <a href="<?php echo e(route('produk.edit', ['id' => $product->id])); ?>" class="btn mb-1 btn-info btn-sm" title="Edit Data">
                            <i class="fas fa-edit">edit</i>
                        </a>
                        <form action="<?php echo e(route('produk.destroy', ['id' => $product->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?')">Delete</button>
                        </form>

                    
                        <!-- Edit link -->
                        
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\testkerja\resources\views/testkerja.blade.php ENDPATH**/ ?>