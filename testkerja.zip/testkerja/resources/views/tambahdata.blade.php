@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<div class="container">
    <h1>Tambah Produk</h1>
    <form method="POST" action="{{ route('produk.store') }}">
        @csrf


        <div class="form-group">
            <label for="namaproduk">Nama Produk:</label>
            <input type="text" name="namaproduk" id="namaproduk" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="hargaproduk">Harga produk</label>
            <input type="number" name="hargaproduk" id="hargaproduk" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="kategori">Kategori</label>
            <select name="kategori" id="kategori" class="form-control" required>
                <option value="" selected disabled>pilih kategori</option>
                @foreach ($kategori as $kategori)
                    <option value="{{ $kategori->id }}">{{ $kategori->kategori }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label for="status">Status</label>
            <select name="status" id="status" class="form-control" required>
                <option value="" selected disabled>pilih status</option>
                @foreach ($status as $status)
                    <option value="{{ $status->id }}">{{ $status->status }}</option>
                @endforeach
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Tambah Produk</button>
    </form>
</div>
