<div class="container">
    <h1>Daftar Produk</h1>
    <button><a href="{{ route('produk.create') }}">Tambah data</a></button>
    <button><a href="{{ route('produk.show') }}">Barang bisa dijual</a></button>

    <!-- Tampilkan data produk di sini sesuai dengan respons API -->
    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Kategori ID</th>
                <th>Status ID</th>
                <th>Action</th>
                <!-- Tambahkan kolom lainnya sesuai kebutuhan -->
            </tr>
        </thead>
        <tbody>
            @foreach ($produk as $product)
                <tr>
                    <td>{{ $product->id }}</td>
                    <td>{{ $product->nama_produk }}</td>
                    <td>{{ $product->harga }}</td>
                    <td>{{ $product->kategori->kategori }}</td>
                    <td>{{ $product->status->status }}</td>
                    <td>
                       
                        <a href="{{ route('produk.edit', ['id' => $product->id]) }}" class="btn mb-1 btn-info btn-sm" title="Edit Data">
                            <i class="fas fa-edit">edit</i>
                        </a>
                        <form action="{{ route('produk.destroy', ['id' => $product->id]) }}" method="post">
                            @csrf
                            @method('delete')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?')">Delete</button>
                        </form>

                    
                        <!-- Edit link -->
                        
                        
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
