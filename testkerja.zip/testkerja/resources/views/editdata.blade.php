
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<form method="POST" action="{{ route('produk.update', ['id' => $produk->id]) }}">
    @csrf
    @method('PUT')
    <div class="form-group">
        <label for="namaproduk">Nama Produk:</label>
        <input type="text" name="namaproduk" id="namaproduk" class="form-control" value="{{ $produk->nama_produk }}" required>
    </div>

    <div class="form-group">
        <label for="hargaproduk">hargaproduk:</label>
        <input type="text" name="hargaproduk" id="hargaproduk" class="form-control" value="{{ $produk->harga }}" required>
    </div>

    <div class="form-group">
        <label for="kategori">Kategori</label>
        <select name="kategori" id="kategori" class="form-control" required>
            <option value="" selected disabled>pilih kategori</option>
            @foreach ($kategori as $kategori)
                <option value="{{ $kategori->id }}">{{ $kategori->kategori }}</option>
            @endforeach
        </select>
    </div>

    <div class="form-group">
        <label for="status">Status</label>
        <select name="status" id="status" class="form-control" required>
            <option value="" selected disabled>pilih status</option>
            @foreach ($status as $status)
                <option value="{{ $status->id }}">{{ $status->status }}</option>
            @endforeach
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Update Produk</button>
</form>
