<?php

use App\Http\Controllers\productcontroller;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::controller(productcontroller::class)->group(function () {
    Route::get('/', 'index')->name('produk.index');
    Route::get('/tambahdata', 'create')->name('produk.create');
    Route::get('/showdata', 'show')->name('produk.show');
    Route::match(['get', 'put'], '/editdata/{id}', 'edit')->name('produk.edit');
    Route::post('/storedata', 'store')->name('produk.store');
    Route::put('/editdata/{id}', 'update')->name('produk.update');
    Route::get('/fetch-data-from-api', 'takeapi')->name('produk.api');
    Route::delete('/delete/{id}', 'destroy')->name('produk.destroy'); 
    
});



