<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use App\Models\kategori;
use App\Models\produk;
use App\Models\status;

class productcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $produk = produk::all();
        $status = status::all();
        $kategori = kategori::all();
        return view('testkerja', compact('produk', 'status', 'kategori',));
    }


    public function takeapi()
    {
        // URL API
        $apiUrl = 'https://recruitment.fastprint.co.id/tes/api_tes_programmer';

        // Username dan password untuk otentikasi
        $username = 'tesprogrammer181223C01';
        $password = 'bisacoding-12-20-21'; // Sesuaikan dengan format yang dijelaskan

        // Membuat instance Guzzle HTTP Client
        $client = new Client();

        // Mengirim permintaan GET ke API dengan otentikasi
        $response = $client->request('GET', $apiUrl, [
            'auth' => [$username, $password]
        ]);

        // Mendapatkan konten dari respons
        $data = $response->getBody()->getContents();

        // Mengonversi JSON menjadi array
        $dataArray = json_decode($data, true);

        // Proses selanjutnya dengan data yang sudah diambil
        // ...

        return response()->json($dataArray);
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $produk = produk::all();
        $status = status::all();
        $kategori = kategori::all();
        return view('tambahdata', compact('produk', 'status', 'kategori',));
    }



    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'namaproduk' => 'required',
            'hargaproduk' => 'required|numeric',
            'kategori' => 'required',
            'status' => 'required',
        ]);

        // Jangan menggunakan 'id' dari $request sebagai parameter
        $produk = produk::find($request->id);

        // Periksa apakah produk sudah ada
        if (!$produk) {
            // Jika tidak ada, buat instance baru
            $produk = new produk();
        }

        // Perbarui nilai-nilai kolom
        $produk->nama_produk = $request->namaproduk;
        $produk->harga = $request->hargaproduk;
        $produk->kategori_id = $request->kategori;
        $produk->status_id = $request->status;

        // Simpan perubahan
        $produk->save();

        return redirect()->route('produk.index')->with('msg', 'Produk Berhasil ditambahkan atau diperbarui');
    }


    /**
     * Display the specified resource.
     */
    public function show()
    {
        $produk = Produk::whereHas('status', function ($query) {
            $query->where('status', 'bisa dijual');
        })->get();

        $status = Status::all();
        $kategori = Kategori::all();

        return view('showdata', compact('produk', 'status', 'kategori'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(produk $produk, $id)
    {
        $produk = produk::where('id', $id)->first();
        $status = status::all();
        $kategori = kategori::all();

        return view('editdata', compact('produk', 'kategori', 'status'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'namaproduk' => 'required',
            'hargaproduk' => 'required|numeric',
            'kategori' => 'required',
            'status' => 'required',
        ]);

        // Find the product by its ID
        $produk = produk::find($id);

        // If the product doesn't exist, redirect back with an error message
        if (!$produk) {
            return redirect()->back()->with('error', 'Produk tidak ditemukan');
        }

        // Update the product with the new data
        $produk->nama_produk = $request->namaproduk;
        $produk->harga = $request->hargaproduk;
        $produk->kategori_id = $request->kategori;
        $produk->status_id = $request->status;

        // Save the changes
        $produk->save();

        return redirect()->route('produk.index')->with('msg', 'Produk berhasil diperbarui');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            // Find the product by its ID
            $produk = produk::find($id);

            // If the product doesn't exist, throw an exception
            if (!$produk) {
                throw new \Exception('Produk tidak ditemukan');
            }

            // Delete the product
            $produk->delete();

            return redirect()->route('produk.index')->with('msg', 'Produk berhasil dihapus');
        } catch (\Exception $e) {
            // Handle any exceptions that occur during the deletion process
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
