<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;


class produk extends Model
{
    protected $table = 'produk';
    protected $fillable = [
        'id',
        'nama_produk', 
        'harga', 
        'kategori_id', 
        'status_id', 
    ];


    public function kategori()
    {
        return $this->belongsTo('App\Models\kategori', 'kategori_id');
    }
    public function status()
    {
        return $this->belongsTo('App\Models\status', 'status_id');
    }
}
